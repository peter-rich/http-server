#!/bin/bash
#declare STRING variable
STRING="Hello World"
#print variable on a screen
echo ${STRING}
